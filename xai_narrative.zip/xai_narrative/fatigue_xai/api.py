"""FastAPI service: the integration surface for the Java Spring Boot gateway.

WebSocket  /ws/{session_id}
    in : one JSON FrameTelemetry per message (session_id taken from the URL)
    out: {"type": "assessment" | "narrative_start" | "narrative_chunk" |
                  "narrative_retry" | "narrative_final" | "narrative_cancelled" | "error", ...}
REST
    POST /v1/narrative/preview      stateless: list of frames -> assessment + narrative (Postman friendly)
    GET  /v1/sessions/{id}/assessment
    GET  /v1/sessions/{id}/narratives?limit=20
    GET  /health

UI contract: ``narrative_chunk`` text is PROVISIONAL.  Replace whatever has been
streamed with ``narrative_final.text`` (validated, or the deterministic fallback).
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
from contextlib import asynccontextmanager
from dataclasses import replace
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from pydantic import BaseModel, ValidationError

from .llm import OllamaClient, llm_from_env
from .narrative import NarrativeConfig, NarrativeService
from .rules import FacsRuleEngine, RuleConfig
from .schemas import FrameTelemetry
from .session import SessionRegistry

log = logging.getLogger("fatigue_xai.api")


def build_registry(llm=None, use_env_llm: bool = True, rule_cfg: Optional[RuleConfig] = None,
                   narrative_cfg: Optional[NarrativeConfig] = None) -> SessionRegistry:
    if llm is None and use_env_llm:
        llm = llm_from_env()
    cfg_path = os.getenv("RULES_JSON")
    if rule_cfg is None and cfg_path:
        rule_cfg = RuleConfig.from_json(cfg_path)
    return SessionRegistry(NarrativeService(llm, narrative_cfg), rule_cfg)


class PreviewRequest(BaseModel):
    frames: List[FrameTelemetry]


def create_app(registry: Optional[SessionRegistry] = None) -> FastAPI:
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        app.state.registry = registry or build_registry()
        llm = app.state.registry.narrator.llm
        if isinstance(llm, OllamaClient) and not await llm.is_up():
            log.warning("Ollama not reachable at %s - narratives will use the deterministic template fallback.",
                        llm.base_url)
        yield
        for s in list(app.state.registry.sessions.values()):
            await s.close()

    app = FastAPI(title="Fatigue Narrative XAI Service", version="0.1.0", lifespan=lifespan)

    @app.get("/health")
    async def health() -> Dict[str, Any]:
        reg: SessionRegistry = app.state.registry
        llm = reg.narrator.llm
        up = await llm.is_up() if isinstance(llm, OllamaClient) else None
        return {"status": "ok", "llm": getattr(llm, "name", "none"), "llm_reachable": up,
                "sessions": len(reg.sessions)}

    @app.websocket("/ws/{session_id}")
    async def ws_endpoint(ws: WebSocket, session_id: str) -> None:
        await ws.accept()
        reg: SessionRegistry = app.state.registry
        queue: asyncio.Queue = asyncio.Queue(maxsize=256)

        async def emit(ev: Dict[str, Any]) -> None:
            try:
                queue.put_nowait(ev)
            except asyncio.QueueFull:   # slow consumer: drop oldest non-final events
                try:
                    queue.get_nowait()
                except asyncio.QueueEmpty:
                    pass
                queue.put_nowait(ev)

        async def sender() -> None:
            while True:
                await ws.send_json(await queue.get())

        sess = reg.get(session_id, emit)
        send_task = asyncio.create_task(sender())
        try:
            while True:
                raw = await ws.receive_text()
                try:
                    data = json.loads(raw)
                    data["session_id"] = session_id
                    frame = FrameTelemetry(**data)
                except (json.JSONDecodeError, ValidationError, TypeError) as e:
                    await emit({"type": "error", "message": "invalid telemetry frame", "detail": str(e)[:300]})
                    continue
                await sess.on_frame(frame)
        except WebSocketDisconnect:
            pass
        finally:
            send_task.cancel()
            await sess.close()
            reg.drop(session_id)

    @app.post("/v1/narrative/preview")
    async def preview(req: PreviewRequest) -> Dict[str, Any]:
        reg: SessionRegistry = app.state.registry
        if not req.frames:
            raise HTTPException(422, "frames must not be empty")
        cfg = replace(reg.cfg or RuleConfig(), assess_every_s=0.0)
        engine = FacsRuleEngine(req.frames[0].session_id, cfg)
        a = None
        for f in req.frames:
            a = engine.ingest(f) or a
        if a is None:
            raise HTTPException(422, "not enough frames to produce an assessment")
        final = await reg.narrator.narrate(a)
        return {"assessment": a.model_dump(), "narrative": final}

    @app.get("/v1/sessions/{session_id}/assessment")
    async def get_assessment(session_id: str) -> Dict[str, Any]:
        s = app.state.registry.sessions.get(session_id)
        if not s or not s.latest:
            raise HTTPException(404, "no assessment yet for this session")
        return s.latest.model_dump()

    @app.get("/v1/sessions/{session_id}/narratives")
    async def get_narratives(session_id: str, limit: int = 20) -> List[Dict[str, Any]]:
        s = app.state.registry.sessions.get(session_id)
        if not s:
            raise HTTPException(404, "unknown session")
        return list(s.narratives)[-max(1, min(limit, 200)):]

    return app


app = create_app()

if __name__ == "__main__":  # pragma: no cover
    import uvicorn
    uvicorn.run("fatigue_xai.api:app", host=os.getenv("HOST", "0.0.0.0"), port=int(os.getenv("PORT", "8100")))
