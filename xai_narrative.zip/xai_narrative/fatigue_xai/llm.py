"""LLM backends.  All stream plain-text chunks.  Decoding is pinned to be as
deterministic as the backend allows (temperature 0, top-k 1, fixed seed)."""
from __future__ import annotations

import asyncio
import json
import os
from typing import AsyncIterator, Dict, List, Optional, Protocol

import httpx

Messages = List[Dict[str, str]]


class LLMClient(Protocol):
    name: str

    def stream(self, messages: Messages) -> AsyncIterator[str]: ...


class OllamaClient:
    """Local Ollama server (https://ollama.com).  Default model: Llama 3.1 8B."""

    def __init__(self, base_url: Optional[str] = None, model: Optional[str] = None,
                 seed: int = 42, num_predict: int = 140, keep_alive: str = "30m", transport=None):
        self.base_url = (base_url or os.getenv("OLLAMA_URL", "http://localhost:11434")).rstrip("/")
        self.model = model or os.getenv("OLLAMA_MODEL", "llama3.1:8b")
        self.seed, self.num_predict, self.keep_alive = seed, num_predict, keep_alive
        self._transport = transport
        self.name = f"ollama:{self.model}"

    async def stream(self, messages: Messages) -> AsyncIterator[str]:
        payload = {
            "model": self.model, "messages": messages, "stream": True, "keep_alive": self.keep_alive,
            "options": {"temperature": 0, "top_k": 1, "top_p": 1, "seed": self.seed,
                        "num_predict": self.num_predict, "num_ctx": 2048},
        }
        timeout = httpx.Timeout(connect=2.0, read=30.0, write=5.0, pool=5.0)
        async with httpx.AsyncClient(timeout=timeout, transport=self._transport) as client:
            async with client.stream("POST", f"{self.base_url}/api/chat", json=payload) as r:
                r.raise_for_status()
                async for line in r.aiter_lines():
                    if not line.strip():
                        continue
                    obj = json.loads(line)
                    if "error" in obj:
                        raise RuntimeError(obj["error"])
                    piece = (obj.get("message") or {}).get("content", "")
                    if piece:
                        yield piece
                    if obj.get("done"):
                        return

    async def is_up(self) -> bool:
        try:
            async with httpx.AsyncClient(timeout=1.5, transport=self._transport) as c:
                r = await c.get(f"{self.base_url}/api/tags")
                return r.status_code == 200
        except Exception:
            return False


class OpenAICompatClient:
    """vLLM / llama.cpp server / any OpenAI-compatible /v1/chat/completions endpoint."""

    def __init__(self, base_url: Optional[str] = None, model: Optional[str] = None,
                 api_key: Optional[str] = None, seed: int = 42, max_tokens: int = 140, transport=None):
        self.base_url = (base_url or os.getenv("OPENAI_COMPAT_URL", "http://localhost:8000/v1")).rstrip("/")
        self.model = model or os.getenv("OPENAI_COMPAT_MODEL", "meta-llama/Meta-Llama-3.1-8B-Instruct")
        self.api_key = api_key or os.getenv("OPENAI_COMPAT_KEY", "EMPTY")
        self.seed, self.max_tokens = seed, max_tokens
        self._transport = transport
        self.name = f"openai-compat:{self.model}"

    async def stream(self, messages: Messages) -> AsyncIterator[str]:
        payload = {"model": self.model, "messages": messages, "stream": True, "temperature": 0,
                   "seed": self.seed, "max_tokens": self.max_tokens}
        headers = {"Authorization": f"Bearer {self.api_key}"}
        timeout = httpx.Timeout(connect=2.0, read=30.0, write=5.0, pool=5.0)
        async with httpx.AsyncClient(timeout=timeout, transport=self._transport) as client:
            async with client.stream("POST", f"{self.base_url}/chat/completions", json=payload, headers=headers) as r:
                r.raise_for_status()
                async for line in r.aiter_lines():
                    if not line.startswith("data:"):
                        continue
                    data = line[5:].strip()
                    if data == "[DONE]":
                        return
                    delta = json.loads(data)["choices"][0].get("delta", {})
                    if delta.get("content"):
                        yield delta["content"]


class ScriptedLLM:
    """Test double: returns canned answers in order (last one repeats)."""

    def __init__(self, answers: List[str], chunk_words: int = 3, delay_s: float = 0.0, fail: bool = False):
        self.answers, self.chunk_words, self.delay, self.fail = answers, chunk_words, delay_s, fail
        self.calls: List[Messages] = []
        self.name = "scripted"

    async def stream(self, messages: Messages) -> AsyncIterator[str]:
        self.calls.append(messages)
        if self.fail:
            raise ConnectionError("scripted failure")
        text = self.answers[min(len(self.calls) - 1, len(self.answers) - 1)]
        words = text.split(" ")
        for i in range(0, len(words), self.chunk_words):
            if self.delay:
                await asyncio.sleep(self.delay)
            yield " ".join(words[i:i + self.chunk_words]) + (" " if i + self.chunk_words < len(words) else "")


def llm_from_env() -> Optional[LLMClient]:
    """NARRATIVE_LLM = ollama (default) | openai | none"""
    kind = os.getenv("NARRATIVE_LLM", "ollama").lower()
    if kind == "none":
        return None
    if kind == "openai":
        return OpenAICompatClient()
    return OllamaClient()
