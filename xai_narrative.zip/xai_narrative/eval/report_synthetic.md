# Narrative layer evaluation (synthetic telemetry)

## Rule engine

- **false_alarm_rate_alert_steady**: 0.0
- **critical_delay_after_first_microsleep_s**: 2.0
- **microsleep_warned_in_advance**: 10/10
- **lead_time_s_median**: 70.0
- **lead_time_s_min**: 60.0
- **level_changes_per_min_drift**: 1.23
- **phase_level_agreement**: 0.975
- **occlusion_flagged_unknown**: 10/10

## Guard (hallucination detection)

- injected hallucinations caught: **180/180** (100.0%)
  (wrong number, advice, medical claim, wrong risk level, ungrounded pulse, ungrounded AU)

## Narrator

- **n**: 157
- **template_factual_violations**: 0
- real-LLM metrics not run (use --ollama with a local Ollama server)
